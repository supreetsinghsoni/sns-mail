create database says;
CREATE TABLE IF NOT EXISTS services (service varchar(100));
